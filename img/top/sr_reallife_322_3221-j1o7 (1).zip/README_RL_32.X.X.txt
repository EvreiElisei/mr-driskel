https://snowrunner.old.mod.io/real-life-mod 
https://mod.io/g/snowrunner/m/real-life-mod
- - - - MOD REQUIRES A LOT OF TIME, ANY SUPPORT IS HIGHLY APPRECIATED - - -
- - Real Life Mod Patreon:    https://www.patreon.com/real_life_mod - - - -
- - Real Life Mod Bootsy:     https://boosty.to/real-life-mod - - - - - - -
- - - - THANK YOU FOR CHOOSING REAL LIFE MOD FOR SNOWRUNNER - - - - - - - -

I. INSTALLATION

0) Download the latest version of the archive from mod.io and open it with WinRAR (no need to extract);
1) Go to the SnowRunner installation folder on your PC: SnowRunner > en_us > preload > paks > client, copy initial.pak to a safe place, this will be your backup;
2) Open initial.pak with WinRAR (the initial.pak in the game folder, not your backup);
3) From SR_RealLife archive, drag & drop [media], [strings], and initial.cache_block to the initial.pak in the game folder. You can install any option you like after this step;
4) Click OK.


II. ADDITIONAL OPTIONS
   Install them after you install the mod (step A above)
   For detailer description, read the corresponding README in the option's folder

--    A.
   The [meshes] folder lets you change GMC MH9500 grill and fixes the bug that mirrored the CAT 770G's rims. 
   Drag & drop [meshes] into shared.pak: SnowRunner > en_us > preload > paks > client. 

--    B.
   Allows selecting driver's appearance: RU is the default one, US is the American one. 

--    C.
   Continue your current save in a different mode with one of the following options or 
   their combo: no recovery, no color zone markers, almost hard mode if you're playing Base Mode.
   For detailed description, read the corresponding README in the option's folder.

--    D.
   Allows playing with default unrealistically light unpacked cargo mass. Open Option D and 
   drag & drop the [media] folder to initial.pak just like you did before. 

--    E. (INCOMPATIBLE WITH REAL LIFE MOD PLUS)
   Allows using different front & rear wheels: narrow tractor ones front and wide rear, 
   or highway front and tractor rear, or other combos, see screenshots on mos.io. 
   !!!THIS OPTION IS INCOMPATIBLE WITH REAL LIFE MOD PLUS!!!

--    F.
   Increases the fuel consumption by 25% and reduces fuel tanker fuel capacities (not fuel weight) 
   to vanilla values. Install both of them or wither one. 

--    H.
   Removes unrealistically modeled front driven axles from the CT680, CT681, HX520, MH9500, Brigadier, WS 49x, 114SD, White WS, Fleetstar, Kodiak

F E A T U R E S   B E L O W   D O   N O T   W O R K

4. If you want load not 3 but 12 logs prior to pack them, 
   do the same with 12_Logs_to_Load [media] folder.

**************************************************************

https://snowrunner.old.mod.io/real-life-mod 
https://mod.io/g/snowrunner/m/real-life-mod

--- МОД ТРЕБУЕТ БОЛЬШОГО КОЛИЧЕСТВА ВРЕМЕНИ, ЛЮБАЯ ПОДДЕРЖКА НЕОЦЕНИМА ---
- Bootsy для Real Life Mod: https://boosty.to/real-life-mod
- Патреон Real Life Mod:    https://www.patreon.com/real_life_mod
--- СПАСИБО, ЧТО ВЫБРАЛИ REAL LIFE МОД ДЛЯ SNOWRUNNER ---

I. УСТАНОВКА

0) Скачав с mod.io последнюю версию мода, открываем его с помощью WinRAR (нет необходимости распаковывать);
1) Заходим в папку, где установлена игра: SnowRunner > en_us > preload > paks > client. В надежное место копируете initial.pak, это будет вашим бекапом
2) Открываем с помощью WinRAR этот initial.pak (нет необходимости распаковывать), находящийся в папке игры
3) Из архива SR_RealLife перетаскиваем [media], [strings], и initial.cache_block в initial.pak, находящийся по пути, описанному в п. 1. После можно 
   установить опции (Options), которые вам нравятся (см. ниже).
4) Нажимаете OK


II. ДОПОЛНИТЕЛЬНЫЕ ОПЦИИ 
   Устанавливаются таким же образом **после** шага А выше
   Для детального описания читайте соответствующий README

--    A.
   Папка [meshes] содержит исправление для вывернутых наизнанку
   колесных дисков CAT 770G. Перетащить папку внутрь shared.pak: SnowRunner > en_us > preload > paks > shared.pak 

--    B.
   Позволяет сменить водителя. RU - дефолтный, US - американский.

--    C.
   Позволяет продолжить свое текущее сохранение обычной игры 
   в одном из следующих режимов или их комбинации: без световой 
   индикации зон, без эвакуации, с платной погрузкой грузов и 
   возвратом в гараж без дозаправки для обычного режима. 
   Детальное описание читайте в README в папке Option C.

--    D.
   Позволяет вернуть дефолтные нереалистично маленькие веса 
   незакрепленным (распакованным) грузам. Откройте Option D 
   и перенесите [media] из этой папки в initial.pak еще раз.

--    E. (НЕСОВМЕСТИМА C REAL LIFE MOD PLUS)
   Позволяет совместить передние обычные колеса и тракторные 
   или арочные задние, или скомбинировать передние и задние 
   из разных комплектов. С этой опцией менять можно будет 
   только задние колеса. Для большей информации смотрите 
   скриншоты с mod.io: https://mod.io/g/snowrunner/m/real-life-mod
   !!!ЭТА ОПЦИЯ НЕСОВМЕСТИМА С REAL LIFE MOD PLUS!!!

--    F.
   Позволяет увеличить расход топлива на 25% и уменьшить объем (но не вес) топлива до ванильных
   значений. Эти опции могут устанавливаться как вместе, так и по отдельности (одно из двух).

--    H.
   Убирает возможность установки нереалистичной модели переднего ведущего моста с CT680, CT681, HX520, MH9500, Brigadier, WS 49x, 114SD, White WS, Fleetstar, Kodiak

Ф У Н К Ц И И   Н И Ж Е   Н Е   Р А Б О Т А Ю Т

3. Если хотите загружать по 12 бревен, прежде чем их будет можно 
   закрепить, сделайте то же самое с папкой [media] из 
   12_Logs_to_Load.