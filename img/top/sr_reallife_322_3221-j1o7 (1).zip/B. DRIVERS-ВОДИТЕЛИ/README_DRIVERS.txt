To choose driver's appearance: 

1) Select the folder (RU is the default, US is an American hidden in the game files) and open it in the archive
2) Drag the corresponding [media] from the mod archive to your initial.pak

*     *     *     *

Чтобы выбрать внешность водителя:

1) Выберите папку (RU - дефолтная внешность, US - водитель, спрятанный в файлах) и откройте её в архиве
2) Перетащите соответствующую [media] из архива мода в initial.pak